#include <Wire.h>
#include <RTClib.h>
#include <MFRC522_I2C.h>
#include <RFIDReader.h>

#define RST_PIN         9       // Pin reset MFRC522
#define SS_PIN          10      // Pin slave select MFRC522

// Objek RTC dan RFID
RTC_DS3231 rtc;
MFRC522_I2C mfrc522(SS_PIN, RST_PIN);

// Variabel untuk menyimpan data
String first_time_value = "";
String last_time_value = "";
int day_value = 0;              // Hari ke-
String condition_value = "Detected"; // Status kondisi
String id_rfid_value = "";      // ID RFID dari kartu/tag

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);  // SDA pada GPIO21, SCL pada GPIO22
  SPI.begin();
  mfrc522.PCD_Init();

  // Inisialisasi RTC
  if (!rtc.begin()) {
    Serial.println("RTC tidak terdeteksi!");
    while (1);
  }

  if (rtc.lostPower()) {
    Serial.println("RTC kehilangan daya, mengatur ulang waktu!");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));  // Set waktu default
  }

  Serial.println("System Initialized!");
}

void loop() {
  // Baca kartu RFID jika tersedia
  if (mfrc522.PICC_IsNewCardPresent() && mfrc522.PICC_ReadCardSerial()) {
    Serial.println("Kartu RFID Terdeteksi!");

    // Dapatkan ID kartu RFID
    id_rfid_value = "";
    for (byte i = 0; i < mfrc522.uid.size; i++) {
      id_rfid_value += String(mfrc522.uid.uidByte[i], HEX);
    }

    Serial.print("ID Kartu: ");
    Serial.println(id_rfid_value);

    // Ambil waktu RTC sekarang
    DateTime now = rtc.now();

    if (first_time_value == "") {  // Jika ini adalah pembacaan pertama
      first_time_value = formatDateTime(now);
    }
    last_time_value = formatDateTime(now);

    // Hitung hari ke- dari waktu awal
    day_value = now.day();

    // Tampilkan data di Serial Monitor
    Serial.print("First Date: ");
    Serial.println(first_time_value);
    Serial.print("Last Date: ");
    Serial.println(last_time_value);
    Serial.print("Hari Ke-: ");
    Serial.println(day_value);
    Serial.print("Kondisi: ");
    Serial.println(condition_value);

    // Simulasi delay membaca kartu
    delay(3000);
  }

  // Simulasi kirim data ke thing
  thingData();
}

// Fungsi untuk memformat waktu RTC ke string
String formatDateTime(DateTime time) {
  char buffer[20];
  sprintf(buffer, "%02d/%02d/%04d %02d:%02d:%02d", 
          time.day(), time.month(), time.year(),
          time.hour(), time.minute(), time.second());
  return String(buffer);
}

// Fungsi simulasi Thing data
void thingData() {
  Serial.println("Mengirim Data ke Thing...");

  // Simulasi struktur output data
  Serial.println("Data yang dikirim:");
  Serial.print("ID_telur 1: ");
  Serial.println(id_rfid_value);
  Serial.print("First Date: ");
  Serial.println(first_time_value);
  Serial.print("Last Date: ");
  Serial.println(last_time_value);
  Serial.print("Hari Ke-: ");
  Serial.println(day_value);
  Serial.print("Detect: ");
  Serial.println(condition_value);

  Serial.println("-----------------------------");
  delay(5000);
}
