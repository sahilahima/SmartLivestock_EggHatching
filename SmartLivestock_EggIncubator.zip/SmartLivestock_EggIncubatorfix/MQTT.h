#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char *ssid = "Wisma Albaik"; // Enter your WiFi name
const char *password = "buwaryati21";  // Enter WiFi password
WiFiClient espClient;
PubSubClient client(espClient);

// MQTT Broker
const char *mqtt_server = "broker.emqx.io";
// const char *topic = "emqx/esp32";
// const char *mqtt_username = "emqx";
// const char *mqtt_password = "public";
const int mqtt_port = 1883;

void mqtt_callback(char *topic, byte *payload, unsigned int length) {
  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  Serial.printf("Message received: %s, Topic: %s\n", message.c_str(), topic);
}

void wifi_mqtt_setup() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
  
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqtt_callback);
}

void reconnect() {
  while (!client.connected()) {
    Serial.println("Reconnecting to MQTT...");
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);
    if (client.connect(clientId.c_str())) {
      Serial.println("Connected to MQTT");
      client.subscribe("SmartLivestock/Egg_Incubator/Button");
    } else {
      Serial.print("Failed: ");
      Serial.println(client.state());
      delay(5000);
    }
  }
}
