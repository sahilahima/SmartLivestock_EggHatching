/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ALGORITHM HEADER PROGRAM
 * AUTHOR : hanifanhilmana
 * PURPOSE :
 * =>
 * TARGET :
 * =>
 * HISTORY :
 * =>
 * NOTE AND REMARKS :
 * => still in development!!!
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#include "esp32-hal-gpio.h"
#define THINGER_SERIAL_DEBUG
#include <ThingerESP32.h>

#define USERNAME "sahilahima"
#define DEVICE_ID "inkubator"
#define DEVICE_CREDENTIAL "GkQxF+6E#Sz%Y!#2"

const char* SSID = "Wisma Albaik";
const char* SSID_PASSWORD = "buwaryati21";

ThingerESP32 thing(USERNAME, DEVICE_ID, DEVICE_CREDENTIAL);

void ThingerIO_setup(){
  thing.add_wifi(SSID, SSID_PASSWORD);
}

void SendData_Thinger(){
  thing["dht11"] >> [] (pson & out){
    out["temperature"]  = temperature_data;
    out["humidity"]     = humidity_data;
    out["heat index"]   = heat_index_c_data;
  };
 
  thing["mic"] >> [] (pson& out) {
    if (mic_data_value > 85) {
        out["mic_data"] = mic_data_value;  // Kirim data mic
        out["suara anak ayam"] = "Yes";    // Kirim "Yes" jika mic > 85
    } else {
        out["mic_data"] = mic_data_value;  // Kirim data mic
        out["suara anak ayam"] = "No";     // Kirim "No" jika mic <= 85
    }
};
   //thing["Data"] >> [] (pson &out) {
    // Data telur
    //out["ID_telur 1"]= id_rfid_value;
    //out["First Date"] = first_time_value;
    //out["Last Date"] = last_time_value;
    //out["Hari Ke-"] = day_value;
    //out["Detect"] = condition_value;

//};

   thing["relay"] >> [] (pson & out){
     out["fan"]     = relay_fan_data;
     out["heater"]  = relay_heater_data;
     out["servo"]   = relay_servo_data;
   };
  thing["relay_fan"] << (digitalPin(RELAY_FAN_PIN));
  thing["relay_heater"] << (digitalPin(RELAY_HEATER_PIN));
  thing["relay_servo"] << (digitalPin(RELAY_SERVO_PIN));

 };
